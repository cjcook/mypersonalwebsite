Thanks for downloading this template!

Template Name: Instant
Template URL: https://templatemag.com/instant-bootstrap-personal-template/
Author: TemplateMag.com
License: https://templatemag.com/license/